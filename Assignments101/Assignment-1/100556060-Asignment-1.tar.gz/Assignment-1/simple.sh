#!/bin/bash
# this is a comment
echo "the number of arguments is $#"
echo "the arguments are $*"
echo "the first argument is $1"
echo "my process number is $$"
ech "enter a number from the keyboard: "
read number
echo "the number you entered was $number"

